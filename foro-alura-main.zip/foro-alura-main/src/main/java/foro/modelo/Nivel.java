package foro.modelo;

public enum Nivel {
	CATEGORIA,
	SUBCATEGORIA,
	CURSO
}