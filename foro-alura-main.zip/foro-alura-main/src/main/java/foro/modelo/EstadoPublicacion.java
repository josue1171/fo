package foro.modelo;

public enum EstadoPublicacion {
	NO_RESPONDIDO,
	NO_SOLUCIONADO,
	SOLUCIONADO,
	CERRADO;
}